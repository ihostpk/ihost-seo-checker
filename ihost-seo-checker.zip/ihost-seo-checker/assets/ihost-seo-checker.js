(() => {
  'use strict';

  const normalizeUrl = (value) => {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol)) {
      throw new Error('Please enter a valid HTTP or HTTPS webpage URL.');
    }
    return url;
  };

  const makeCheck = (title, detail, status) => ({ title, detail, status });

  function inspectDocument(doc, finalUrl) {
    const title = (doc.querySelector('title')?.textContent || '').trim();
    const description = (doc.querySelector('meta[name="description"]')?.getAttribute('content') || '').trim();
    const canonical = (doc.querySelector('link[rel~="canonical"]')?.getAttribute('href') || '').trim();
    const robots = (doc.querySelector('meta[name="robots"]')?.getAttribute('content') || '').trim().toLowerCase();
    const h1s = Array.from(doc.querySelectorAll('h1')).map(el => (el.textContent || '').trim()).filter(Boolean);
    const images = Array.from(doc.images);
    const missingAlt = images.filter(img => !img.hasAttribute('alt') || img.getAttribute('alt').trim() === '');
    const links = Array.from(doc.querySelectorAll('a[href]'));
    const genericLinks = links.filter(a => /^(click here|read more|learn more|here)$/i.test((a.textContent || '').trim()));

    const checks = [];
    checks.push(makeCheck(
      'Title tag',
      title ? `${title.length} characters. ${title.length >= 30 && title.length <= 60 ? 'Length is within a common guideline.' : 'Review the title length and make it clear and unique.'}` : 'No title tag was found.',
      !title ? 'fail' : (title.length >= 30 && title.length <= 60 ? 'pass' : 'warn')
    ));
    checks.push(makeCheck(
      'Meta description',
      description ? `${description.length} characters. ${description.length >= 70 && description.length <= 160 ? 'Length is within a common guideline.' : 'Consider a concise, useful description.'}` : 'No meta description was found.',
      !description ? 'fail' : (description.length >= 70 && description.length <= 160 ? 'pass' : 'warn')
    ));
    checks.push(makeCheck(
      'H1 heading',
      h1s.length === 1 ? 'One H1 heading found.' : `${h1s.length} H1 headings found. Aim for one clear main heading where appropriate.`,
      h1s.length === 1 ? 'pass' : (h1s.length === 0 ? 'fail' : 'warn')
    ));
    checks.push(makeCheck(
      'Canonical URL',
      canonical ? `Canonical tag found: ${canonical}` : 'No canonical tag was found.',
      canonical ? 'pass' : 'warn'
    ));
    checks.push(makeCheck(
      'Robots meta',
      robots ? `Robots directive: ${robots}` : 'No robots meta tag found; the page may use search-engine defaults. Check HTTP headers too.',
      robots.includes('noindex') ? 'warn' : 'pass'
    ));
    checks.push(makeCheck(
      'Image alt text',
      images.length ? `${missingAlt.length} of ${images.length} images have missing or empty alt attributes. Decorative images can use alt="".` : 'No images were detected on the page.',
      missingAlt.length === 0 ? 'pass' : 'warn'
    ));
    checks.push(makeCheck(
      'Descriptive link text',
      genericLinks.length ? `${genericLinks.length} link(s) use generic text such as “Read more” or “Click here”. Add context where helpful.` : 'No common generic link labels were detected.',
      genericLinks.length ? 'warn' : 'pass'
    ));
    checks.push(makeCheck(
      'HTTPS',
      finalUrl.protocol === 'https:' ? 'The final page URL uses HTTPS.' : 'The final page URL does not use HTTPS.',
      finalUrl.protocol === 'https:' ? 'pass' : 'fail'
    ));
    return checks;
  }

  document.querySelectorAll('.ihost-seo-tool').forEach((tool) => {
    const form = tool.querySelector('.ihost-seo-form');
    const input = tool.querySelector('input[name="url"]');
    const button = form.querySelector('button[type="submit"]');
    const status = tool.querySelector('.ihost-seo-status');
    const results = tool.querySelector('.ihost-seo-results');
    const scoreNode = tool.querySelector('.ihost-seo-score-number');
    const summary = tool.querySelector('.ihost-seo-summary');
    const list = tool.querySelector('.ihost-seo-checklist');

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      results.hidden = true;
      status.textContent = '';
      let url;
      try {
        url = normalizeUrl(input.value.trim());
      } catch (error) {
        status.textContent = error.message || 'Please enter a valid URL.';
        return;
      }

      button.disabled = true;
      button.textContent = 'Checking…';
      status.textContent = 'Trying to read the webpage. Some websites block browser-based checks.';
      try {
        const response = await fetch(url.href, { mode: 'cors', credentials: 'omit', redirect: 'follow' });
        if (!response.ok) throw new Error(`The website returned HTTP ${response.status}.`);
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('text/html') && !contentType.includes('application/xhtml+xml')) {
          throw new Error('The URL did not return an HTML webpage.');
        }
        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const finalUrl = new URL(response.url || url.href);
        const checks = inspectDocument(doc, finalUrl);
        const passed = checks.filter(check => check.status === 'pass').length;
        const score = Math.round((passed / checks.length) * 100);

        scoreNode.textContent = `${score}`;
        summary.textContent = `${passed} of ${checks.length} checks passed. Treat this as a quick checklist, not a ranking score.`;
        list.replaceChildren();
        checks.forEach((check) => {
          const item = document.createElement('li');
          item.className = check.status;
          const mark = document.createElement('span');
          mark.className = 'ihost-seo-mark';
          mark.setAttribute('aria-hidden', 'true');
          mark.textContent = check.status === 'pass' ? '✓' : (check.status === 'warn' ? '!' : '×');
          const content = document.createElement('div');
          const title = document.createElement('strong');
          title.textContent = check.title;
          const detail = document.createElement('small');
          detail.textContent = check.detail;
          content.append(title, detail);
          item.append(mark, content);
          list.append(item);
        });
        results.hidden = false;
        status.textContent = `Check complete for ${finalUrl.hostname}.`;
      } catch (error) {
        status.textContent = `${error.message || 'Could not read this webpage.'} This commonly happens when the website blocks cross-origin browser requests (CORS). Try another URL or use a server-side/API-based checker for broader compatibility.`;
      } finally {
        button.disabled = false;
        button.textContent = 'Check SEO';
      }
    });
  });
})();
