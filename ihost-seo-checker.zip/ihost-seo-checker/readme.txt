=== iHost SEO Checker ===
Contributors: ihostpakistan
Tags: seo, seo checker, on-page seo, website audit, ihost
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight browser-based on-page SEO checklist for WordPress pages and posts.

== Description ==

Use the [ihost_seo_checker] shortcode to add a basic SEO checklist to a page. Checks include title, meta description, H1 count, canonical URL, robots meta, image alt attributes, generic link labels, and HTTPS.

Note: The browser-based checker may not work on sites that block cross-origin requests (CORS). It is not a full SEO audit and does not predict rankings.

== Installation ==

1. Upload the plugin ZIP through Plugins > Add New Plugin > Upload Plugin.
2. Activate the plugin.
3. Add [ihost_seo_checker] to a page or post.

== Changelog ==

= 1.0.0 =
* Initial release.
