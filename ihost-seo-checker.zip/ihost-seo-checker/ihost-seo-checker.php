<?php
/**
 * Plugin Name: iHost SEO Checker
 * Plugin URI: https://www.ihost.com.pk/
 * Description: A lightweight on-page SEO checker for WordPress pages and posts.
 * Version: 1.0.0
 * Author: iHost Pakistan
 * Author URI: https://www.ihost.com.pk/
 * License: GPL-2.0-or-later
 * Text Domain: ihost-seo-checker
 */

if (!defined('ABSPATH')) {
    exit;
}

final class IHost_SEO_Checker {
    public function __construct() {
        add_shortcode('ihost_seo_checker', array($this, 'render_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
    }

    public function register_assets() {
        wp_register_style(
            'ihost-seo-checker',
            plugin_dir_url(__FILE__) . 'assets/ihost-seo-checker.css',
            array(),
            '1.0.0'
        );
        wp_register_script(
            'ihost-seo-checker',
            plugin_dir_url(__FILE__) . 'assets/ihost-seo-checker.js',
            array(),
            '1.0.0',
            true
        );
    }

    public function render_shortcode() {
        wp_enqueue_style('ihost-seo-checker');
        wp_enqueue_script('ihost-seo-checker');

        ob_start();
        ?>
        <section class="ihost-seo-tool" aria-labelledby="ihost-seo-title">
            <div class="ihost-seo-header">
                <span class="ihost-seo-kicker">FREE WEBSITE TOOL</span>
                <h2 id="ihost-seo-title">iHost SEO Checker</h2>
                <p>Check the basic on-page SEO elements of a webpage.</p>
            </div>
            <form class="ihost-seo-form">
                <label for="ihost-seo-url">Webpage URL</label>
                <div class="ihost-seo-input-row">
                    <input id="ihost-seo-url" name="url" type="url"
                        placeholder="https://example.com/page/" required
                        inputmode="url" autocomplete="url">
                    <button type="submit">Check SEO</button>
                </div>
                <p class="ihost-seo-note">The page is checked in your browser. Results may vary depending on browser access and page restrictions.</p>
            </form>
            <div class="ihost-seo-status" role="status" aria-live="polite"></div>
            <div class="ihost-seo-results" hidden>
                <div class="ihost-seo-score">
                    <span class="ihost-seo-score-number">—</span>
                    <span><strong>Basic SEO score</strong><small>Based on the checks below, not a Google ranking prediction.</small></span>
                </div>
                <div class="ihost-seo-summary"></div>
                <ul class="ihost-seo-checklist"></ul>
                <p class="ihost-seo-disclaimer">This is a basic technical review, not a full SEO audit. It does not measure backlinks, Core Web Vitals, indexing status, or search rankings.</p>
            </div>
            <footer class="ihost-seo-footer">Built by <a href="https://www.ihost.com.pk/" target="_blank" rel="noopener noreferrer">iHost Pakistan</a></footer>
        </section>
        <?php
        return ob_get_clean();
    }
}

new IHost_SEO_Checker();
