# iHost SEO Checker

A lightweight WordPress plugin that adds a browser-based on-page SEO checklist to any page using a shortcode.

**Website:** https://www.ihost.com.pk/

## Features

- Checks title tag and approximate title length
- Checks meta description and approximate length
- Checks H1 heading count
- Checks for a canonical URL
- Checks the page's robots meta directive
- Flags images with missing or empty `alt` attributes
- Flags common generic link labels
- Checks whether the final URL uses HTTPS
- Responsive interface with accessible status updates
- No tracking, external API, or API key required

## Requirements

- WordPress 5.8+
- PHP 7.4+
- A modern browser with JavaScript enabled

## Installation

1. In WordPress admin, go to **Plugins → Add New Plugin → Upload Plugin**.
2. Upload `ihost-seo-checker.zip`.
3. Activate **iHost SEO Checker**.
4. Create or edit a page and add this shortcode:

   ```text
   [ihost_seo_checker]
   ```

5. Publish the page and test a publicly accessible HTTPS webpage.

## Important limitation: browser CORS

This plugin reads target pages directly from the visitor's browser. Many websites block cross-origin requests with CORS, so the check will not work for every URL. This is intentional: the plugin does not proxy arbitrary URLs through your server, which could introduce SSRF and abuse risks.

For broad compatibility, a future version could use a carefully secured server-side service with strict URL/IP validation, timeouts, response-size limits, and rate limiting.

## Security and privacy

- The plugin does not save submitted URLs or results in the WordPress database.
- The plugin does not send data to iHost or a third-party API.
- The checker only attempts to read the URL submitted by the visitor.
- This is a basic checklist, not a full SEO audit or a guarantee of Google rankings.

## Development

Repository structure:

```text
ihost-seo-checker/
├── ihost-seo-checker.php
├── assets/
│   ├── ihost-seo-checker.css
│   └── ihost-seo-checker.js
├── readme.txt
├── LICENSE
└── README.md
```

## Contributing

Bug reports and improvements are welcome. Please test changes on a staging WordPress site before using them on a live website.

## License

GPL-2.0-or-later. See [LICENSE](LICENSE).
